-- Create Database 
create database library;
use library;

-- Create Tables
-- Table: tbl_publisher
CREATE TABLE tbl_publisher (
    publisher_PublisherName VARCHAR(255) PRIMARY KEY,
    publisher_PublisherAddress TEXT,
    publisher_PublisherPhone VARCHAR(15)
);

-- Table: tbl_book
CREATE TABLE tbl_book (
    book_BookID INT PRIMARY KEY,
    book_Title VARCHAR(255),
    book_PublisherName VARCHAR(255),
    FOREIGN KEY (book_PublisherName) REFERENCES tbl_publisher(publisher_PublisherName)
);

-- Table: tbl_book_authors
CREATE TABLE tbl_book_authors (
    book_authors_AuthorID INT PRIMARY KEY AUTO_INCREMENT,
    book_authors_BookID INT,
    book_authors_AuthorName VARCHAR(255),
    FOREIGN KEY (book_authors_BookID) REFERENCES tbl_book(book_BookID)
);

-- Table: tbl_library_branch
CREATE TABLE tbl_library_branch (
    library_branch_BranchID INT PRIMARY KEY AUTO_INCREMENT,
    library_branch_BranchName VARCHAR(255),
    library_branch_BranchAddress TEXT
);

-- Table: tbl_book_copies
CREATE TABLE tbl_book_copies (
    book_copies_CopiesID INT PRIMARY KEY AUTO_INCREMENT,
    book_copies_BookID INT,
    book_copies_BranchID INT,
    book_copies_No_Of_Copies INT,
    FOREIGN KEY (book_copies_BookID) REFERENCES tbl_book(book_BookID),
    FOREIGN KEY (book_copies_BranchID) REFERENCES tbl_library_branch(library_branch_BranchID)
);

-- Table: tbl_borrower
CREATE TABLE tbl_borrower (
    borrower_CardNo INT PRIMARY KEY,
    borrower_BorrowerName VARCHAR(255),
    borrower_BorrowerAddress TEXT,
    borrower_BorrowerPhone VARCHAR(15)
);

-- Table: tbl_book_loans
CREATE TABLE tbl_book_loans (
    book_loans_LoansID INT PRIMARY KEY AUTO_INCREMENT,
    book_loans_BookID INT,
    book_loans_BranchID INT,
    book_loans_CardNo INT,
    book_loans_DateOut DATE,
    book_loans_DueDate DATE,
    FOREIGN KEY (book_loans_BookID) REFERENCES tbl_book(book_BookID),
    FOREIGN KEY (book_loans_BranchID) REFERENCES tbl_library_branch(library_branch_BranchID),
    FOREIGN KEY (book_loans_CardNo) REFERENCES tbl_borrower(borrower_CardNo)
);

-- Key Analysis Questions
SELECT book_Title, book_PublisherName
FROM tbl_book;

SELECT borrower_BorrowerName, borrower_BorrowerAddress, borrower_BorrowerPhone
FROM tbl_borrower;

SELECT b.book_Title AS Book,
       COALESCE(lb.library_branch_BranchName, CONCAT('BranchID-', bc.book_copies_BranchID)) AS Branch,
       bc.book_copies_No_Of_Copies AS Copies
FROM tbl_book_copies bc
LEFT JOIN tbl_book b ON bc.book_copies_BookID = b.book_BookID
LEFT JOIN tbl_library_branch lb ON bc.book_copies_BranchID = lb.library_branch_BranchID
ORDER BY b.book_Title, Branch;

SELECT 'tbl_book' AS TableName, COUNT(*) AS Rowss FROM tbl_book
UNION
SELECT 'tbl_book_copies', COUNT(*) FROM tbl_book_copies
UNION
SELECT 'tbl_library_branch', COUNT(*) FROM tbl_library_branch
UNION
SELECT 'tbl_book_loans', COUNT(*) FROM tbl_book_loans
UNION
SELECT 'tbl_borrower', COUNT(*) FROM tbl_borrower
UNION
SELECT 'tbl_publisher', COUNT(*) FROM tbl_publisher;

/* ================================================================
   1️⃣  Check which Branch IDs in tbl_book_copies don’t exist 
       in tbl_library_branch
   ================================================================ */
SELECT DISTINCT bc.book_copies_BranchID AS MissingBranchID_in_Copies
FROM tbl_book_copies bc
LEFT JOIN tbl_library_branch lb
       ON bc.book_copies_BranchID = lb.library_branch_BranchID
WHERE lb.library_branch_BranchID IS NULL;

/* ================================================================
   2️⃣  Check which Branch IDs in tbl_library_branch 
       are not used in tbl_book_copies
   ================================================================ */
SELECT DISTINCT lb.library_branch_BranchID AS UnusedBranchID_in_BranchTable,
       lb.library_branch_BranchName
FROM tbl_library_branch lb
LEFT JOIN tbl_book_copies bc
       ON lb.library_branch_BranchID = bc.book_copies_BranchID
WHERE bc.book_copies_BranchID IS NULL;

/* ================================================================
   3️⃣  Check which Publisher names in tbl_book 
       don’t exist in tbl_publisher
   ================================================================ */
SELECT DISTINCT b.book_PublisherName AS MissingPublisher_in_Books
FROM tbl_book b
LEFT JOIN tbl_publisher p
       ON b.book_PublisherName = p.publisher_PublisherName
WHERE p.publisher_PublisherName IS NULL;

/* ================================================================
   4️⃣  Check which Publisher names in tbl_publisher 
       are not used in tbl_book
   ================================================================ */
SELECT DISTINCT p.publisher_PublisherName AS UnusedPublisher_in_PublisherTable
FROM tbl_publisher p
LEFT JOIN tbl_book b
       ON p.publisher_PublisherName = b.book_PublisherName
WHERE b.book_PublisherName IS NULL;

/* ================================================================
   5️⃣  Quick look at Branch IDs and names 
   ================================================================ */
SELECT library_branch_BranchID, library_branch_BranchName
FROM tbl_library_branch
ORDER BY library_branch_BranchID;

/* ================================================================
   6️⃣  Quick look at Publisher names 
   ================================================================ */
SELECT publisher_PublisherName FROM tbl_publisher
ORDER BY publisher_PublisherName;

/* ================================================================
   7️⃣  Quick look at Book Publisher names 
   ================================================================ */
SELECT DISTINCT book_PublisherName FROM tbl_book
ORDER BY book_PublisherName;

SELECT DISTINCT book_copies_BranchID 
FROM tbl_book_copies;

UPDATE tbl_book_copies
SET book_copies_BranchID = 2
WHERE book_copies_BranchID = 1;
SELECT DISTINCT book_copies_BranchID FROM tbl_book_copies;

SELECT br.borrower_BorrowerName
FROM tbl_borrower br
LEFT JOIN tbl_book_loans bl ON br.borrower_CardNo = bl.book_loans_CardNo
WHERE bl.book_loans_CardNo IS NULL;




